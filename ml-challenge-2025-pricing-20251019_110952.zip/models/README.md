# Models Directory

This directory contains trained model files.
Run `python run_pipeline.py` to generate the models.
